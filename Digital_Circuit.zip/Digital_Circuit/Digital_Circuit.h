boolean AND(boolean A, boolean B)
{
	if(A == true && B == true)
		return true;
	else
		return false;
}

boolean AND3(boolean A, boolean B, boolean C)
{
	if(A == true && B == true && C == true)
		return true;
	else
		return false;
}

boolean AND4(boolean A, boolean B, boolean C, boolean D)
{
	if(A == true && B == true && C == true && D == true)
		return true;
	else
		return false;
}

boolean OR(boolean A, boolean B)
{
	if(A == false && B == false)
		return false;
	else
		return true;
}

boolean OR3(boolean A, boolean B, boolean C)
{
	if(A == false && B == false && C == false)
		return false;
	else
		return true;
}

boolean OR4(boolean A, boolean B, boolean C, boolean D)
{
	if(A == false && B == false && C == false && D == false)
		return false;
	else
		return true;
}

boolean NOT(boolean A)
{
	if(A == false)
		return true;
	else
		return false;
}

boolean NAND(boolean A, boolean B)
{
	if(A == true && B == true)
		return false;
	else
		return true;
}

boolean NAND3(boolean A, boolean B, boolean C)
{
	if(A == true && B == true && C == true)
		return false;
	else
		return true;
}

boolean NAND4(boolean A, boolean B, boolean C, boolean D)
{
	if(A == true && B == true && C == true && D == true)
		return false;
	else
		return true;
}

boolean NOR(boolean A, boolean B)
{
	if(A == false && B == false)
		return true;
	else
		return false;
}

boolean NOR3(boolean A, boolean B, boolean C)
{
	if(A == false && B == false && C == false)
		return true;
	else
		return false;
}

boolean NOR4(boolean A, boolean B, boolean C, boolean D)
{
	if(A == false && B == false && C == false && D == false)
		return true;
	else
		return false;
}

boolean XOR(boolean A, boolean B)
{
	if((A == true && B == true) || (A == false && B == false))
		return false;
	else
		return	true;
}

boolean XNOR(boolean A, boolean B)
{
	if((A == true && B == true) || (A == false && B == false))
		return true;
	else
		return	false;
}


/*
  para configurar o flip-flop tipo D,
  é necessário criar uma variável global
  chamada clock, que receberá um sinal
  externo de clock. Este flip-flop está
  configurado para a borda de descida e
  a leitura do clock será feita a cada
  1 milisegundo. Também é necessário criar
  uma variável global booleana D em qualquer
  porta. Para configurar a saída Q barrada,
  basta declarar qualquer outra variável
  e inverter a saída de FFD usando a função
  NOT
*/
boolean FFD(void)
{
	int a = digitalRead(D);
	int temp1 = digitalRead(clock);
	delay(1);
	int temp2 = digitalRead(clock);

	if(temp1 > temp2)
		return digitalRead(D);
	else
		return a;
}












